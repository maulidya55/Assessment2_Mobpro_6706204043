package com.d3if4043.kalkulator_jodoh.model

data class Output (
    val nama: String,
    val namaPasangan: String,
    val hasil: String
)