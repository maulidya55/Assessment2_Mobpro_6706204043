package com.d3if4043.kalkulator_jodoh.model

data class CoupleGoals (
    val goals: String,
    val image: String
)