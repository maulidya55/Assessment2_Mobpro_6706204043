package com.d3if4043.kalkulator_jodoh.ui

import androidx.fragment.app.Fragment
import com.d3if4043.kalkulator_jodoh.R

class AboutFragment: Fragment(R.layout.fragment_about)